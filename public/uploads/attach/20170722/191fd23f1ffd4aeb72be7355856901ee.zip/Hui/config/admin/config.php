<?php
return [
	'app_trace'              => false,

    // 系统表
    'tables_list' => 'doc|document|channel|models|fields|setapi|settings|singlepage|user',
	
	// 系统字段
    'fields_list' =>'table|id|cid|uid|topic|color|aurl|isout|outurl|keywords|describle|hits|photo|photos|attach|content|sorting|status|isrec|tags|isdraft|ctime|aid|utime',
    
    // 默认跳转页面对应的模板文件
    'dispatch_success_tmpl'  => 'public/prompt',
    'dispatch_error_tmpl'    => 'public/prompt',

];
