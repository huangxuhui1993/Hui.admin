<?php
return [
	'app_trace'              => false,
];
