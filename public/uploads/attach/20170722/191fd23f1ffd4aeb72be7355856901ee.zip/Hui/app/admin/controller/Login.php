<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;
use think\Db;
use app\admin\model\User as UserModel;

/**
 * 系统登录控制器
 * Class Login
 * @package app\admin\controller
 */
class Login extends Controller
{

    public function index(){
        return $this->fetch();
    }

    /**
     * 登录信息验证
     * @param Request $request
     * @return \think\response\Json
     */
    public function checkLogin(Request $request){
        if($request->isPost()){
            
            $data = $request->post();
            // 数据验证
            $result = $this->validate($data,'Login');
            
            if(true !== $result){
                return json(['info'=>$result]);
            }else{
                
                // 检测验证码
                if(!$this->check($data['code'])){
                    return json(['info'=>'验证码错误']);
                }
                $user = Db::name('user')->where(['username'=>$data['name']])->find();
                // 设置session
                session('uid',$user['id']);
                session('uname',$user['username']);
                session('loginip',$user['loginip']);
                session('logintime',$user['logintime']);
                // 登录修改
                UserModel::where('id',$user['id'])->update([
                    'loginnumber' => $user['loginnumber'] + 1,
                    'logintime'   => time(),
                    'loginip'     => $request->ip(),
                ]);
                // 记录日志
                system_logs('登录系统',$user['username'],1);
                return json(['status'=>1,'url'=>url('index/index')]);
            }
        }else{
            die('非法操作！');
        }
    }

    /**
     * 验证码检测
     * @param string $code
     * @return bool
     */
    public function check($code=''){
        if (!captcha_check($code)) {
            return false;
        } else {
            return true;
        }
    }

    // 退出系统
    public function logout(){
        if(session('uid') && session('uname')){
            // 记录日志
            system_logs('退出系统',session('uname'),1);
            session('uid',null);
            session('uname',null);
            session(null);
            $this->redirect('Login/index');
        }else{
            $this->redirect('Login/index');
        }

    }

}
