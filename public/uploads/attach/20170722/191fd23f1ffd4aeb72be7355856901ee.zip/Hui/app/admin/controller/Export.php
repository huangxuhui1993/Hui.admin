<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use think\Request;
use think\Config;
use think\Db;
use app\admin\model\Export as ExportModel;
use app\admin\model\Logs;

/**
 * Excel导出控制器
 * Class Export
 * @package app\admin\controller
 */
class Export extends Base
{
	// 类初始化函数
    public function _initialize(){
        parent::_initialize();
        set_time_limit(0);
        ini_set('memory_limit','300M');
		error_reporting(E_ALL);
		date_default_timezone_set('Asia/Shanghai');	
    }

    /**
     * CSV导出信息
     * @param  Request $request
     * @return json
     */
    public function csvExport(Request $request){

        $data = Db::name('logs')->order('id desc')->select();
    	$titleList = ['ID', '管理员', '客户端IP','操作','状态','时间'];  
		$fileName = 'Hui.admin系统日志信息';

	    $csvData = '';
	    $nums = count($titleList);  
	    for ($i = 0; $i < $nums - 1; $i++){  
	        $csvData .= '"' . $titleList[$i] . '",';  
	    }  
	    $csvData .= '"' . $titleList[$nums - 1] . "\"\r\n";
	    foreach ($data as $key => $row){  
	        $i = 0;  
	        foreach ($row as $_key => $_val){  
	            $_val = str_replace("\"", "\"\"", $_val);  
	            if ($i < ($nums - 1)){  
	                $csvData .= '"' . $_val . '",';  
	            }elseif ($i == ($nums - 1)){  
	                $csvData .= '"' . $_val . "\"\r\n";  
	            }  
	            $i++;  
	        }  
	        unset($data[$key]);  
	    }
        $dir = HUI_FILES.Config::get('websetup.export_dir').DS;
        $file_name = date('YmdHis').'.csv';
        $hand = file_put_contents($dir.$file_name,$csvData);
        chmod($dir.$file_name,0777); // 设置权限

        $url = Config::get('websetup.export_dir').DS.$file_name;

		if($hand){
			# 记录导出文件信息
    		$db = new ExportModel();
			unset($data);
			$data = [
				'uid' => session('uid'),
				'title' => $fileName,
				'name' => $file_name,
				'url' => $url,
				'ext' => 'csv'
			];
			if($db->allowField(true)->save($data)){
				return json(['error' => 0,'file'=> DS.Config::get('hui_files_path').DS.$url]);
			}else{
				return json(['error' => 1,'msg'  => '导出文件记录失败！']);	
			}
		}else{
			return json(['error' => 1,'msg'  => '信息导出失败！']);
		}
    }


    /**
     * PHPExcel导出信息
     * @Author   Hui
     * @DateTime 2017-06-29T23:07:56
     * @return   文件
     */
	public function excelExport(Request $request){
		// 实例化Excel类
       	$objPHPExcel = new \PHPExcel();
		
		// 设置excel的属性：
        $objPHPExcel->getProperties()
        			->setCreator("Hui.admin系统日志信息") 		// 创建人
                    ->setLastModifiedBy("Hui.admin") 			// 最后修改人
                    ->setTitle("日志数据Excel导出") 				// 标题
                    ->setSubject("日志数据Excel导出") 			// 题目
                    ->setDescription("日志数据Excel导出") 		// 描述
                    ->setKeywords("日志")						// 关键字
                    ->setCategory("信息");						// 种类
        
        // 设置当前的sheet
        $objPHPExcel->setActiveSheetIndex(0);
		$objPHPExcel->getActiveSheet()->getStyle('B')->getNumberFormat()->setFormatCode(\PHPExcel_Style_NumberFormat::FORMAT_TEXT);
		
		// 设置第一行值
		self::setValue($objPHPExcel,'A1',date('Y-m-d').' Hui.admin系统日志信息');
		self::setFontBold($objPHPExcel,'A1');			// 字体加粗		
		self::setFontSize($objPHPExcel,'A1',16);		// 字体大小	
		self::setRowHeight($objPHPExcel,1,26);			// 设置行高			
		self::setUnitHV($objPHPExcel,'A1');				// 水平垂直居中
		self::mergeCells($objPHPExcel,'A1','F1');		// 合并单元格

		// 设置第二行值
		self::setValue($objPHPExcel,'A2','ID');
		self::setValue($objPHPExcel,'B2','管理员');
		self::setValue($objPHPExcel,'C2','客户端IP');
		self::setValue($objPHPExcel,'D2','操作');
		self::setValue($objPHPExcel,'E2','状态');
		self::setValue($objPHPExcel,'F2','时间');

		self::setWrapText($objPHPExcel,'A2');
		self::setFontBold($objPHPExcel,'A2');
		self::setFontSize($objPHPExcel,'A2',10);			
		self::setUnitHV($objPHPExcel,'A2');

		self::setWrapText($objPHPExcel,'B2');
		self::setFontBold($objPHPExcel,'B2');	
		self::setFontSize($objPHPExcel,'B2',10);	
		self::setUnitHV($objPHPExcel,'B2');

		self::setWrapText($objPHPExcel,'C2');
		self::setFontBold($objPHPExcel,'C2');	
		self::setFontSize($objPHPExcel,'C2',10);	
		self::setUnitHV($objPHPExcel,'C2');

		self::setWrapText($objPHPExcel,'D2');
		self::setFontBold($objPHPExcel,'D2');	
		self::setFontSize($objPHPExcel,'D2',10);	
		self::setUnitHV($objPHPExcel,'D2');

		self::setWrapText($objPHPExcel,'E2');
		self::setFontBold($objPHPExcel,'E2');	
		self::setFontSize($objPHPExcel,'E2',10);	
		self::setUnitHV($objPHPExcel,'E2');

		self::setWrapText($objPHPExcel,'F2');
		self::setFontBold($objPHPExcel,'F2');	
		self::setFontSize($objPHPExcel,'F2',10);	
		self::setUnitHV($objPHPExcel,'F2');

		self::setRowHeight($objPHPExcel,2,26);	// 设置行高


        // 以下处理Excel里的数据
        $data = Db::name('logs')->order('id desc')->select();

        $i = 3;
        foreach($data as $key => $val){
			self::setValue($objPHPExcel,'A'.$i,$val['id']); self::setUnitHV($objPHPExcel,'A'.$i);
			self::setValueExp($objPHPExcel,'B'.$i,$val['username']); self::setUnitHV($objPHPExcel,'B'.$i);
			self::setValueExp($objPHPExcel,'C'.$i,$val['ip']); self::setUnitHV($objPHPExcel,'C'.$i);
			self::setValueExp($objPHPExcel,'D'.$i,$val['operate']); self::setUnitHV($objPHPExcel,'D'.$i);
			self::setValueExp($objPHPExcel,'E'.$i,$val['status'] = 1?'成功':'失败'); self::setUnitHV($objPHPExcel,'E'.$i);
			self::setValueExp($objPHPExcel,'F'.$i,date('Y-m-d H:i:s',$val['time'])); self::setUnitHV($objPHPExcel,'F'.$i);
        	++$i;
        }

    	// 设置列表宽度
		self::setColWidth($objPHPExcel,"A",10); 
		self::setColWidth($objPHPExcel,"B",15);
		self::setColWidth($objPHPExcel,"C",15);
		self::setColWidth($objPHPExcel,"D",80);
		self::setColWidth($objPHPExcel,"E",10);
 		self::setColWidth($objPHPExcel,"F",22);

 		// 设置sheet名称
        $objPHPExcel->getActiveSheet()->setTitle('Logs');
        
		// 保存为xls文件
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');

		// 保存路径
		$dir = HUI_FILES.Config::get('websetup.export_dir').DS;

		if(!is_dir($dir)){	
			mkdir($dir);
			chmod($dir,0777); // 设置权限
		}

		$str = str_replace('.php', '.xls',"ExportLogs_".uniqid().".php");
		$objWriter->save($dir.$str);
		return json([
			'error' => 0,
			'file'=> DS.Config::get('hui_files_path').DS.Config::get('websetup.export_dir').DS.$str
		]);
	}

	/**
	 * 设置单元格的值
	 * @Author   Hui
	 * @DateTime 2017-06-29T23:22:43
	 * @param    Object          $object  PHPExcel类
	 * @param    string          $unit 所在行
	 * @param    [type]          $val  值
	 */
	private static function setValue($object,$unit,$val){
		$object->getActiveSheet()->setCellValue($unit,$val);
	}

	// 设置单元格的值
	private static function setValueExp($object,$unit,$val){
		$object->getActiveSheet()->setCellValueExplicit($unit,$val,\PHPExcel_Cell_DataType::TYPE_STRING);
	}

	// 行高设置
	private static function setRowHeight($object,$row,$val){
		$object->getActiveSheet()->getRowDimension($row)->setRowHeight($val);
	}

	// 宽度设置
	private static function setColWidth($object,$col,$val){
		$object->getActiveSheet()->getColumnDimension($col)->setWidth($val);	
	}

	// 自动宽度
	private static function setColAutoWidth($object,$col){
		$object->getActiveSheet()->getColumnDimension($col)->setAutoSize(true);	
	}

	// 字体加粗
	private static function setFontBold($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getFont()->setBold(true);	
	}

	// 字体大小
	private static function setFontSize($object,$unit,$fsize){
		$object->getActiveSheet()->getStyle($unit)->getFont()->setSize($fsize);
	}

	// 水平居左
	private static function setUnitL($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);	
	}

	// 水平居右
	private static function setUnitR($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);	
	}

	// 水平居中
	private static function setUnitH($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);	
	}

	// 垂直居中
	private static function setUnitV($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);	
	}

	// 水平，垂直居中
	private static function setUnitHV($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);	
	}

	// 合并单元格
	private static function mergeCells($object,$units,$unite){
		$object->getActiveSheet()->mergeCells($units.':'.$unite);
	}

	// 自动换行
	private static function setWrapText($object,$unit){
		$object->getActiveSheet()->getStyle($unit)->getAlignment()->setWrapText(true);	
	}

}
