<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use org\util\HttpCurl;
use think\Request;
use think\Validate;
use think\Cache;
use app\admin\model\User;
use app\admin\model\AuthGroupAccess;
use app\admin\model\AuthGroup;
use \Exception;

/**
 * 公共方法控制器
 * Class Common
 * @package app\admin\controller
 */
class Common extends Base{
    
    public function _initialize(){
        parent::_initialize();
    }

    /**
     * 账号设置
     * @param  Request $request
     * @return 
     */
    public function userSetup(Request $request){
		$id = session('uid');
		// 实例化模型	
		$ag = new AuthGroup();
		$aga = new AuthGroupAccess();

		if($request->isPost()){

			$user = new User();
			$data = $request->post();
			// 验证数据
			$validate = new Validate([
				['id','require','抱歉缺少参数！'],
				['username','require|unique:user|min:5','请输入管理账号！|抱歉，该账号已存在！|账号最少五位！'],
				['password','min:6','密码最少六位！'],
				['email','email','请输入正确的邮箱地址！'],
				['group_id','require','请选择管理组！'],
				['state','require','请选择账号状态！']
			]);

			if(!$validate->check($data)) {
				$this->redirect('Common/userSetup','',302,['code'=>'error','msg'=>$validate->getError()]);
			}else{
				if($user->allowField(true)->save($data,['id'=>$id])){
					// 修改用户组
					$aga->save(['group_id' => $data['group_id']],['uid' => $id]);
					system_logs('账号设置',session('uname'),1);
					$this->redirect('Common/userSetup','',302,['code'=>'success','msg'=>'设置成功！']);
				}else{
					system_logs('账号设置',session('uname'),0);
					$this->redirect('Common/userSetup','',302,['code'=>'error','msg'=>'设置失败！']);
				}
			}
			return;
		}

		// 获取全部原始数据
		$det_rs = User::get($id)->getData();
		$this->assign('rs',$det_rs);
		// 全部角色
		$group = $ag->where(['status'=>1])->select();
		$this->assign('group',$group);
		// 用户角色
		$aga = $aga->where(['uid'=>$id])->find();
		$this->assign('aga',$aga);

		return $this->fetch();
    }

    /**
     * 清除上传文件
     * @param Request $request
     * @return \think\response\Json
     */
    public function deleteFile(Request $request){
        if($request->isAjax()) {
            $att_id = $request->param('id/d');
            if(!empty($att_id) && isset($att_id)){
                if(delete_file($att_id)){
                    // 记录日志
                    system_logs('清除上传文件',session('uname'),1);
                    return json(['error'=>0]);
                }else{
                    // 记录日志
                    system_logs('清除上传文件',session('uname'),0);
                    return json(['error'=>1]);
                }
            }
        }
    }

    /**
     * 查看源代码
     * @param Request $request 请求信息
     * @return mixed
     */
	public function codemirror(Request $request){
		$path = $request->param('path');
		$file = ROOT_PATH.$path;
		if(!is_file($file)){
			$code = '文件不存在!';
		}elseif(!is_readable($file)){
            $code = '文件不可读!';
        }else{
			# 读取文件内容
			$str = file_get_contents($file);
			$code = htmlentities($str);
		}
		system_logs('查看源代码'.$file,session('uname'),1);
		$this->assign('code',$code);
		$this->assign('file',str_replace('\\','/',$file));
		return $this->fetch('public/codemirror');
	}

    /**
     * 修改源代码
     * @param Request $request 请求信息
     * @return \think\response\Json
     */
	public function savecode(Request $request){
		if($request->isAjax()){
			$data = $request->post();
			// 验证数据
			$validate = new Validate([
				['file','require','文件路径为空!'],
				['code','require','代码内容为空!'],
			]);
			if(!$validate->check($data)) {
				return json(['error'=>1,'msg' => $validate->getError()]);
			}else{
				$file = $data['file'];
				if(!is_file($file)){
					return json(['error'=>1,'msg'=>'文件不存在!']);
				}elseif(!is_writable($file)){
                    return json(['error'=>1,'msg'=>'文件不可写!']);
                }else{
					// 内容写入文件
					if(file_put_contents($file,$data['code'])){
						system_logs('修改源代码'.$file,session('uname'),1);
						return json(['error'=>0,'msg'=>'代码修改成功']);
					}else{
                        system_logs('修改源代码'.$file,session('uname'),0);
                        return json(['error'=>0,'msg'=>'代码修改失败']);
                    }
				}	
			}
		}else{
			system_logs('修改源代码，非法操作！',session('uname'),0);
			return json(['error'=>1,'msg'=>'非法操作!']);
		}
	}

    /**
     * 发送邮件
     * @param Request $request
     * @return mixed|\think\response\Json
     */
	public function email(Request $request){
        if($request->isAjax()){
            $data = $request->post();
            // 验证数据
            $validate = new Validate([
                ['email','require','邮件地址为空!'],
                ['title','require','邮件标题为空!'],
                ['content','require','邮件内容为空!'],
            ]);
            if(!$validate->check($data)) {
                return json(['error'=>1,'msg' => $validate->getError()]);
            }else{
                 $data = [
                 	'title' => $data['title'],
                 	'content' => $data['content'],
                 	'email' => explode(',', $data['email']),
                 ];
                 try{
                  	send_mailer($data);
                  	system_logs('发送邮件',session('uname'),1);
                  	return json(['error'=>0]);
                 }catch(Exception $e) {
                     system_logs('发送邮件：'.$e->getMessage(),session('uname'),0);
                     return json(['error'=>1,'msg' => $e->getMessage()]);
                 }
            }
        }else{
            return $this->fetch();
        }
	}

    /**
     * 清除缓存
     * @param Request $request
     * @return \think\response\Json
     */
	public function clearcache(Request $request){
		if($request->isAjax()){
			# 清除cache缓存
			$cache = Cache::clear();
			# 清除temp缓存
			$temp = array_map('unlink', glob(TEMP_PATH . '*.php'));
			if(is_dir(TEMP_PATH)){
				rmdir(TEMP_PATH);
			}
	    	if($cache && $temp){
	    		system_logs('清除缓存',session('uname'),1);
	    		return json(['error'=>0]);
	    	}else{
                system_logs('清除缓存',session('uname'),0);
	    		return json(['error'=>1]);
	    	}
		}
	}

    /**
     * 获取新闻
     * @param Request $request
     * @return string|\think\response\Json
     */
	public function news(Request $request){
		if($request->isAjax()){
			$data = $request->post('type');
			if(empty($data)){
				return json(['message'=>'参数错误！','code'=>1]);
			}
			// Ajax实时新闻
			$curl = new HttpCurl();
			$url = 'http://wangyi.butterfly.mopaasapp.com/news/api';
			$data = [
				'type' => $data,
				'page' => 1,
				'limit' => 8
			];
			$result = $curl::get($url,$data);
			$news = json_decode($result,true);
			$newslist = $news['list'];
			// 截取新闻标题
			foreach($newslist as $k=>$v){
				$newslist[$k]['title'] = msubstr($v['title'],0,15);
			}
			return json($newslist);
		}else{
			return '非法操作！';
		}

	}

}
