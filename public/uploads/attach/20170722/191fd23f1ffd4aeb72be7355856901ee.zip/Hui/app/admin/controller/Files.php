<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use think\Request;
use app\admin\model\Attach;
use app\admin\model\Convert;
use app\admin\model\Export;

/**
 * 文件管理控制器
 * Class Files
 * @package app\admin\controller
 */
class Files extends Base
{
	static private $bread = '文件管理';

	/**
	 * 上传文件列表
	 * @return 
	 */
	public function uploadFile(Request $request){
		$where = [];
		# 状态查询
		$state = $request->post('state/d');
		$this->assign('state',$state);
		if(!empty($state)){
			if ($state === 1) {
				$where['aid'] = ['neq',0];
			}else{
				$where['aid'] = ['eq',0];
			}
		}

		# 关键字查询
		$keywords = preg_replace('# #','',$request->post('keywords'));
		$this->assign('keywords',$keywords);
		if(!empty($keywords)){
			$where['title|ext|name'] = ['like', '%'.$keywords.'%'];
		}

        $db = new Attach();
		$list = $db->where($where)->order('id desc')->paginate(40);
		$this->assign('list',$list);
		$this->assign('count',$db->where($where)->count());

		# 面包屑
		$this->assign('bread',breadcrumb([self::$bread,'上传文件']));
		return $this->fetch();
	}

	/**
	 * 转换文件列表
	 * @return 
	 */
	public function conversionFile(Request $request){
		$where = [];
        # 关键字查询
        $keywords = preg_replace('# #','',$request->post('keywords'));
        $this->assign('keywords',$keywords);
        if(!empty($keywords)){
            $where['title|name'] = ['like', '%'.$keywords.'%'];
        }

        $db = new Convert();
		$list = $db->where($where)->order('id desc')->paginate(40);
		$this->assign('list',$list);
		$this->assign('count',$db->where($where)->count());

		# 面包屑
		$this->assign('bread',breadcrumb([self::$bread,'转换文件']));
		return $this->fetch();
	}

	/**
	 * 导出文件列表
	 * @return 
	 */
	public function exportFile(Request $request){
        $where = [];
        # 关键字查询
        $keywords = preg_replace('# #','',$request->post('keywords'));
        $this->assign('keywords',$keywords);
        if(!empty($keywords)){
            $where['title|name'] = ['like', '%'.$keywords.'%'];
        }

        $db = new Export();
		$list = $db->where($where)->order('id desc')->paginate(40);
		$this->assign('list',$list);
		$this->assign('count',$db->where($where)->count());

		# 面包屑
		$this->assign('bread',breadcrumb([self::$bread,'导出文件']));
		return $this->fetch();
    }

    /**
     * 删除转换文件
     * @param Request $request
     */
    public function conversionDel(Request $request){
        if($request->isGet()){
            $id = $request->param('id/d');
            if(!isset($id) || empty($id)){
                $this->redirect('Files/conversionFile','',302,['code'=>'error','msg'=>'参数错误！']);
            }else{
                $db = Convert::get($id);
                if($db){
                    if($db->delete()){
                        // 删除文件
                        $url = HUI_FILES.$db->url;
                        if(is_file($url)){
                            unlink($url);
                        }
                        system_logs('删除转换文件',session('uname'),1);
                        $this->redirect('Files/conversionFile','',302,['code'=>'success','msg'=>'转换文件删除成功！']);
                    }else{
                        system_logs('删除转换文件',session('uname'),0);
                        $this->redirect('Files/conversionFile','',302,['code'=>'error','msg'=>'转换文件删除失败！']);
                    }
                }else{
                    $this->redirect('Files/conversionFile','',302,['code'=>'error','msg'=>'数据不存在！']);
                }
            }
        }
    }

    /**
     * 删除导出文件
     * @param Request $request
     */
    public function exportDel(Request $request){
        if($request->isGet()){
            $id = $request->param('id/d');
            if(!isset($id) || empty($id)){
                $this->redirect('Files/exportFile','',302,['code'=>'error','msg'=>'参数错误！']);
            }else{
                $db = Export::get($id);
                if($db){
                    if($db->delete()){
                        // 删除文件
                        $url = HUI_FILES.$db->url;
                        if(is_file($url)){
                            unlink($url);
                        }
                        system_logs('删除导出文件',session('uname'),1);
                        $this->redirect('Files/exportFile','',302,['code'=>'success','msg'=>'导出文件删除成功！']);
                    }else{
                        system_logs('删除导出文件',session('uname'),0);
                        $this->redirect('Files/exportFile','',302,['code'=>'error','msg'=>'导出文件删除失败！']);
                    }
                }else{
                    $this->redirect('Files/exportFile','',302,['code'=>'error','msg'=>'数据不存在！']);
                }
            }
        }
    }

}
