<?php
namespace app\index\controller;
use think\Controller;
use think\Request;
use think\Validate;
use org\util\HttpCurl;
use think\Db;

class Index extends Controller{

	public function index(){
		$browder = get_os().'  '.get_browser_lang();
		$this->assign('browder',$browder);
		return $this->fetch();
	}

	// 分享接口
	public function share(Request $request){
		if($request->isAjax()){

			$data = $request->post();

			// 验证数据
			$validate = new Validate([
				['site','require','分享平台为空!'],
				['title','require','分享标题为空!']
			]);

			if(!$validate->check($data)) {
				return json(['error'=>1,'msg' => $validate->getError()]);
			}else{
				$curl = new HttpCurl();
				$url = 'http://api.bshare.cn/share/post.c';

				$parameter = [
					'site' => $data['site'],
					'publisherUuid' => 'c8980ee7-feef-474f-abad-ffa6457c769f',
					'url' => 'http://www.3dzyw.com',
					'title' => $data['title'],
					'pic' => $data['pic']
				];

				$result = $curl::post($url,$parameter);
				
				if(!empty($result)){
					return json(['error'=>0,'msg'=>$result]);
				}else{
					return json(['error'=>1,'msg' => '分享失败']);
				}
				
			}

		}else{
			return '非法操作！';
		}
	}

}
